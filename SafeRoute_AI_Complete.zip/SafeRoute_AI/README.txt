SAFEROUTE AI - COMPLETE MINI WEBSITE

HOW TO OPEN
1. Download and extract SafeRoute_AI_Complete.zip.
2. Open the extracted folder.
3. Double-click index.html (Chrome or Edge recommended).
4. Keep an internet connection enabled. The map, geocoding and routing use public online services.

FEATURES
- Start and destination search.
- Retrieves available driving route options from the OSRM demo routing service.
- Compares routes against hazard markers saved in the browser.
- Highlights the route with the lowest illustrative hazard score in green.
- Displays route distance, estimated travel time and nearby reported hazards.
- Interactive OpenStreetMap. Click the map to fill latitude and longitude in the hazard form.
- Add hazard reports (pothole/damaged road, waterlogging, other issue).
- Reports are saved in local browser storage and shown on the map.
- Fictional Coimbatore sample markers included for demonstration.

IMPORTANT LIMITATIONS
- This is a student prototype, not a certified navigation or emergency system.
- The risk score and 100-metre proximity rule are illustrative and are not scientifically validated.
- Sample markers are fictional demo data, not verified road reports.
- No live traffic, live weather, verified accident database, official road-condition feed or automatic AI image detection.
- Reports are stored only in the same browser/device and are not shared with other users.
- Public geocoding/routing services may be slow, unavailable or rate-limited. Alternative routes may not always be returned.
- A route with fewer saved reports is not guaranteed to be safe. Follow traffic rules, road signs and current local conditions.

SERVICES / ATTRIBUTION
Map tiles: OpenStreetMap contributors.
Geocoding: Nominatim public service.
Routing: OSRM demo server.
This prototype uses public services and is not affiliated with those providers.
